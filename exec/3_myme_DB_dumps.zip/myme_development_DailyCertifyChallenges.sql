-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: ssafy-pjt1-dbserver.cotmr33tcon0.ap-northeast-2.rds.amazonaws.com    Database: myme_development
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `DailyCertifyChallenges`
--

DROP TABLE IF EXISTS `DailyCertifyChallenges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DailyCertifyChallenges` (
  `id` int NOT NULL AUTO_INCREMENT,
  `img_addr` varchar(200) DEFAULT NULL,
  `content` text,
  `certification_datetime` datetime NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `ChallengeParticipationId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ChallengeParticipationId` (`ChallengeParticipationId`),
  CONSTRAINT `DailyCertifyChallenges_ibfk_1` FOREIGN KEY (`ChallengeParticipationId`) REFERENCES `ChallengeParticipations` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DailyCertifyChallenges`
--

LOCK TABLES `DailyCertifyChallenges` WRITE;
/*!40000 ALTER TABLE `DailyCertifyChallenges` DISABLE KEYS */;
INSERT INTO `DailyCertifyChallenges` VALUES (3,'https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629283858934.png','첫 인증입니다','2021-08-17 15:00:00','2021-08-18 10:51:03','2021-08-18 10:51:03',5),(4,'https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629285024695_mj.PNG','커밋완료','2021-08-17 15:00:00','2021-08-18 11:10:30','2021-08-18 11:10:30',NULL),(5,'https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629285045390_angry.PNG','ㅂㄷㅂㄷ','2021-08-17 15:00:00','2021-08-18 11:10:53','2021-08-18 11:10:53',NULL),(6,'https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629285110567_netflix.PNG','netflix 인증!','2021-08-17 15:00:00','2021-08-18 11:11:52','2021-08-18 11:11:52',7),(7,'https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629285292153_taxi.PNG','인증합니다!','2021-08-17 15:00:00','2021-08-18 11:14:53','2021-08-18 11:14:53',NULL),(8,'https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629300506243_202181902657.jpg','인증합니다!','2021-08-18 15:00:00','2021-08-18 15:28:28','2021-08-18 15:28:28',NULL),(9,'https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629316947115_%E1%84%89%E1%85%B3%E1%84%8F%E1%85%B3%E1%84%85%E1%85%B5%E1%86%AB%E1%84%89%E1%85%A3%E1%86%BA_2021-08-09_%E1%84%8B%E1%85%A9%E1%84%','인증합니다!','2021-08-18 15:00:00','2021-08-18 20:02:29','2021-08-18 20:02:29',5),(10,'https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629317964987_eng.jfif','인증합니다!','2021-08-18 15:00:00','2021-08-18 20:19:34','2021-08-18 20:19:34',14),(11,'https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629322100399_%E1%84%83%E1%85%A1%E1%86%AF%E1%84%85%E1%85%B5%E1%84%80%E1%85%B5_%E1%84%8B%E1%85%B5%E1%86%AB%E1%84%8C%E1%85%B3%E1%86%BC%21.jpg','인증합니다!','2021-08-18 15:00:00','2021-08-18 21:28:26','2021-08-18 21:28:26',16),(12,'https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629334708244_mj.PNG','인증합니다!','2021-08-19 00:00:00','2021-08-19 00:58:30','2021-08-19 00:58:30',NULL),(13,'https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629337631111.png','강아지','2021-08-18 15:00:00','2021-08-19 01:47:14','2021-08-19 01:47:14',NULL),(14,'https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629342633265.jpg','인증합니다!','2021-08-18 15:00:00','2021-08-19 03:10:34','2021-08-19 03:10:34',2),(15,'https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629347856748.png','인증합니다!','2021-08-18 15:00:00','2021-08-19 04:37:38','2021-08-19 04:37:38',NULL),(16,'https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629348758185.png','인증합니다!','2021-08-18 15:00:00','2021-08-19 04:52:40','2021-08-19 04:52:40',NULL),(17,'https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629348787543.PNG','인증합니다!','2021-08-18 15:00:00','2021-08-19 04:53:09','2021-08-19 04:53:09',NULL),(18,'https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629350831535.jpg','인증합니다!','2021-08-18 15:00:00','2021-08-19 05:27:16','2021-08-19 05:27:16',NULL),(19,'https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629350992791.jpg','인증합니다!','2021-08-18 15:00:00','2021-08-19 05:29:56','2021-08-19 05:29:56',34),(20,'https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629351904429.png','종부세???','2021-08-18 15:00:00','2021-08-19 05:45:16','2021-08-19 05:45:16',6),(21,'https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629351973146_BGS_%281%29.png','인증합니다!','2021-08-18 15:00:00','2021-08-19 05:46:15','2021-08-19 05:46:15',4),(22,'https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629352399163.jpg','인턴 쉐도잉!\n','2021-08-18 15:00:00','2021-08-19 05:53:29','2021-08-19 05:53:29',7),(23,'https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629354116653.jpeg','인증합니다!','2021-08-18 15:00:00','2021-08-19 06:21:59','2021-08-19 06:21:59',NULL),(24,'https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629358117833.png','인증합니다!','2021-08-18 15:00:00','2021-08-19 07:28:40','2021-08-19 07:28:40',10),(25,'https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629358143801.png','인증합니다!','2021-08-18 15:00:00','2021-08-19 07:29:06','2021-08-19 07:29:06',11),(26,'https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629374084732.jpg','인증합니다!','2021-08-18 15:00:00','2021-08-19 11:54:48','2021-08-19 11:54:48',50);
/*!40000 ALTER TABLE `DailyCertifyChallenges` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-20  0:54:03
