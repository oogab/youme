-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: ssafy-pjt1-dbserver.cotmr33tcon0.ap-northeast-2.rds.amazonaws.com    Database: myme_development
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `Challenges`
--

DROP TABLE IF EXISTS `Challenges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Challenges` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `img_addr` varchar(200) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_general_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `period` int NOT NULL,
  `certification_cycle` int NOT NULL,
  `total_number_of_certification` int NOT NULL,
  `category` int NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `UserId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `UserId` (`UserId`),
  CONSTRAINT `Challenges_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `Users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Challenges`
--

LOCK TABLES `Challenges` WRITE;
/*!40000 ALTER TABLE `Challenges` DISABLE KEYS */;
INSERT INTO `Challenges` VALUES (1,'1일 1커밋','https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629282897646_grass.png','1일 1커밋하고 예쁜 잔디 심어봐요!\n알고리즘 뿌셔뿌셔~','2021-08-18','2021-09-30',43,1,43,5,'2021-08-18 10:35:31','2021-08-18 10:35:31',1),(2,'달려라 하니','https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629283068820_running.jpg','달리기는 심폐지구력과 전신 근력을 향상시킵니다. 에너지 소모량이 많아서 체중 조절 효과도 크죠. \n운동하는 내내 신체의 모든 부위를 사용할 수 있어 전신의 살을 빼고 몸매를 매끈하게 만드는 데에 큰 도움이 됩니다.\n같이 달려보아요!!','2021-08-18','2021-09-15',28,7,12,1,'2021-08-18 10:39:31','2021-08-18 10:39:31',1),(3,'경제기사 읽기','https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629283504661_economic.PNG','뚜렷한 경제 관념을 갖고 싶으신 분? 자산을 모으고 싶으신 분? 꾸준히 경제 공부를 하고 싶으신 분? 모두 모여라!','2021-08-18','2021-09-01',14,7,6,2,'2021-08-18 10:45:55','2021-08-18 10:45:55',1),(4,'미드/영드 쉐도잉','https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629283677342_shadowing.PNG','자신의 마음에 드는 영화 또는 드라마를 한편을 골라 쉐도잉 하면서 영어 실력도 높이고 영화 감상도 하고! 어떤 일을 하던 재미있어야 꾸준히 할 수 있죠. ','2021-08-18','2021-09-01',14,5,10,2,'2021-08-18 10:49:45','2021-08-18 10:49:45',1),(5,'출근길 택시 안타기','https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629283896477_taxi.PNG','대중교통 출근의 장점: 충동비용을 아낀다, 생각보다 큰 다이어트 효과, 빠른 이동시간 등등.. 아침에 조금만 더 일찍 일어나서 택시 대신 대중교통을 이용해봐요. 1석 다조~','2021-08-23','2021-09-25',33,2,25,7,'2021-08-18 10:53:42','2021-08-18 10:53:42',1),(6,'화나는 일이 있을때마다 1818원 저축하기','https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629284123296_angry.PNG','돈이 있었는데요, 없었습니다.^_ㅠ 내 텅장의 주범! 홧김소비! 스트레스를 받아 홧김에 지출하게 되는 비용. 스트레스를 받지 않았다면 발생하지 않았을 비용이다. .\n티끌모아 태산! 저축을 통한 뿌듯함으로 화난 마음을 달래고, 티끌모아 태산을 직접 실천해볼 수 있습니다.','2021-08-18','2021-09-15',28,7,12,7,'2021-08-18 10:57:40','2021-08-18 10:57:40',1),(7,'매일 TIL 작성하기','https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629317899180_icons8-edit-chat-history-100.png','TIL(Today I Learned)을 작성하면서 공부를 시작해볼까요?','2021-08-19','2021-09-30',42,1,42,2,'2021-08-18 20:19:09','2021-08-18 20:19:09',2),(8,'제로 웨이스트 실천하기','https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629347496995.PNG','제로(Zero) + 웨이스트(Waste): 생활 속에서 생산되는 쓰레기를 최소한으로 줄이는 모든 행위. 플라스틱 줄이기, 일회용 컵 대신에 텀블러! 비닐 쇼핑백 대신 장바구니! 알고 실천하는 분리배출! 지구를 살립시다','2021-08-23','2021-09-20',28,8,8,3,'2021-08-19 04:33:16','2021-08-19 04:33:16',5),(9,'일주일에 카레 한번 먹기','https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629347590387.png','카레는 몸에 좋아요','2021-10-06','2021-11-03',28,9,4,4,'2021-08-19 04:33:17','2021-08-19 04:33:17',2),(10,'땅끄부부 홈트 영상 운동하기','https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629347755456.PNG','특유의 친근한 분위기와 따라하기 쉬운 운동법으로 홈트 초보들이 도전하기 쉬운 땅끄 부부 영상으로 함께 건강과 체중관리 함께 해봅시다.','2021-08-19','2021-09-02',14,7,6,1,'2021-08-19 04:36:46','2021-08-19 04:36:46',5),(13,'관악산 등반하기','https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629354998847.png','등반 테스트','2021-08-19','2021-08-19',1,1,1,1,'2021-08-19 06:36:45','2021-08-19 06:36:45',3),(15,'하루에 커피 한잔','https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629356740089.PNG','하루에 커피 한잔!','2021-08-19','2021-08-27',8,2,6,3,'2021-08-19 07:05:48','2021-08-19 07:05:48',5),(17,'안녕하세요','https://ssafymyme.s3.ap-northeast-2.amazonaws.com/original/1629361490891.jpeg','드디어 성공인가?','2021-08-19','2021-08-21',2,1,2,3,'2021-08-19 08:25:31','2021-08-19 08:25:31',3);
/*!40000 ALTER TABLE `Challenges` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-20  0:54:03
