-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: ssafy-pjt1-dbserver.cotmr33tcon0.ap-northeast-2.rds.amazonaws.com    Database: myme_development
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `Habits`
--

DROP TABLE IF EXISTS `Habits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Habits` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `icon_src` varchar(50) DEFAULT NULL,
  `content` text,
  `assist_link` varchar(100) DEFAULT NULL,
  `time_required` int NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `UserId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `UserId` (`UserId`),
  CONSTRAINT `Habits_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `Users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Habits`
--

LOCK TABLES `Habits` WRITE;
/*!40000 ALTER TABLE `Habits` DISABLE KEYS */;
INSERT INTO `Habits` VALUES (1,'입실체크',NULL,'edu.ssafy 입실체크&설문조사','',1,'2021-08-18 11:05:58','2021-08-18 11:05:58',1),(2,'씻기',NULL,'씻기','_V8kpeOAnfY',10,'2021-08-18 11:06:51','2021-08-18 11:06:51',1),(3,'음료 준비',NULL,'정규시간에 마실 음료 준비','',3,'2021-08-18 11:07:19','2021-08-18 11:07:19',1),(4,'아침러닝',NULL,'아침에 뜀박질','',30,'2021-08-18 11:07:50','2021-08-18 11:07:50',1),(5,'퇴실체크',NULL,'edu.ssafy 퇴실체크&건강설문','',1,'2021-08-18 11:08:43','2021-08-18 11:08:43',1),(6,'홈트',NULL,'홈트하기','gMaB-fG4u4g',30,'2021-08-18 11:09:29','2021-08-18 11:09:29',1),(7,'독서하기',NULL,'독서 30페이지','',30,'2021-08-18 14:07:53','2021-08-18 14:29:11',3),(8,'음료 준비하기',NULL,'잠을 깨울 음료 준비하기','',3,'2021-08-18 14:08:23','2021-08-18 14:08:23',3),(9,'알고리즘 문제풀기',NULL,'1일 1알고!','',40,'2021-08-18 14:09:02','2021-08-18 14:09:02',3),(10,'홈트레이닝',NULL,'홈트레이닝','sqQpL1wKW6M',20,'2021-08-18 14:30:13','2021-08-18 16:57:49',3),(11,'생수 500ml 마시기',NULL,'물은 자주 마셔야 해요','hDXELtJE_Bk',1,'2021-08-18 20:22:31','2021-08-19 04:35:22',2),(12,'5분 명상하기',NULL,'잠도 깰 겸 명상하기','dZewQEbQQM0',5,'2021-08-18 20:23:33','2021-08-18 20:23:33',2),(13,'이불 개기',NULL,'이불 개는 걸 생활화 합시다.','',1,'2021-08-18 20:24:22','2021-08-18 20:24:22',2),(14,'싸피 입실설문 하기',NULL,'8시 30분~8시 59분 사이에 출첵을 안하면 눈물이 날걸요?','',1,'2021-08-18 20:29:34','2021-08-18 20:29:34',2),(15,'독서하기',NULL,'매일 아침 인간은 왜 외로움을 느끼는가 조금씩 읽기!','',30,'2021-08-18 21:23:19','2021-08-18 21:23:19',4),(16,'음료 준비하기',NULL,'오전 공부를 시작하기 전 마실 것들 준비하자','',10,'2021-08-18 21:23:57','2021-08-18 21:23:57',4),(17,'알고리즘 문제풀기',NULL,'매일 적어도 한 문제씩 풀기!','',60,'2021-08-18 21:25:00','2021-08-18 21:25:00',4),(18,'저녁 홈 트레이닝!',NULL,'매일 저녁 홈 트레이닝을 통해서 건강을 챙깁시다!','CYcLODSeC-c&t=267s',15,'2021-08-18 21:26:12','2021-08-18 21:26:12',4),(21,'ㅇㅇ',NULL,'ㅇㅇ','',1,'2021-08-19 04:15:07','2021-08-19 04:15:07',5),(22,'ㅇㅇㅇ',NULL,'ㅇㅇㅇ','',1,'2021-08-19 04:15:19','2021-08-19 04:15:19',5),(23,'입 근육 풀어주기',NULL,'기기기기기기기긱기ㅣ기긱기기기기기기기기기기기기기기기기기기기기기기기기기기기기기기기기기기기ㅣㄱ기기기기ㅣㄱ기기기기기기기기기','',5,'2021-08-19 04:52:48','2021-08-19 04:58:40',6),(24,'간단 스트레칭',NULL,'스터디 전에 꼭 스트레칭 하고 시작하자!!','',5,'2021-08-19 04:54:36','2021-08-19 04:54:36',6),(41,'코딩 열심히하기',NULL,'코딩엔 역시 BTS 노래지~','zR463NBnVvg',50,'2021-08-19 15:02:08','2021-08-19 15:02:08',1),(42,'버즈랑 핸드폰 충전하기',NULL,'내일을 위해 버즈랑 핸드폰은 꼭 충전해야해요','',3,'2021-08-19 15:05:06','2021-08-19 15:05:06',1),(43,'창문 열기',NULL,'청소 전에 꼭 환기부터 시키기','',1,'2021-08-19 15:07:42','2021-08-19 15:07:42',1),(44,'청소기 돌리기',NULL,'머리카락 박멸','',15,'2021-08-19 15:08:11','2021-08-19 15:12:16',1),(45,'밀대걸레 밀기',NULL,'밀자밀자','',15,'2021-08-19 15:08:33','2021-08-19 15:12:12',1),(46,'화장실 청소',NULL,'깨끗하게!!','gw3ltsoYBtI',30,'2021-08-19 15:09:38','2021-08-19 15:12:06',1);
/*!40000 ALTER TABLE `Habits` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-20  0:54:03
