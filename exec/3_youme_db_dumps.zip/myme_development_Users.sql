-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: ssafy-pjt1-dbserver.cotmr33tcon0.ap-northeast-2.rds.amazonaws.com    Database: myme_development
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `Users`
--

DROP TABLE IF EXISTS `Users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `nickname` varchar(20) DEFAULT NULL,
  `password` varchar(100) NOT NULL,
  `age` int DEFAULT NULL,
  `gender` varchar(5) DEFAULT NULL,
  `post_code` varchar(10) DEFAULT NULL,
  `main_address` varchar(50) DEFAULT NULL,
  `sub_address` varchar(50) DEFAULT NULL,
  `phone_number` varchar(15) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `nickname` (`nickname`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users`
--

LOCK TABLES `Users` WRITE;
/*!40000 ALTER TABLE `Users` DISABLE KEYS */;
INSERT INTO `Users` VALUES (1,'김싸피','test@ssafy.com','SSAFY','$2b$12$AkuTQj2LYM0Jf10tn/I/r.O8ptUdYcVRwUhFbMr/.VrfRBf5eebB2',25,'여','11680','서울 강남구 테헤란로 212','싸피','010-1234-5678','2021-08-18 10:28:48','2021-08-18 10:28:48'),(2,'테스트3','test3@test.com','테스트3','$2b$12$HeuAMGGE49SvilMTQAqYJuxtKeQ8HfQJTudVMdpCvAGwRWz6NWkuS',10,'기타','28200','인천 남동구 백범로 455-1','.','010-3333-3333','2021-08-18 10:37:09','2021-08-18 10:37:09'),(3,'백상욱','oogab@naver.com','우크','$2b$12$rPZT4zIwmDRwJuLaat3XletzurF8vUIhksyTgU00m.4eGqHQvm06O',27,'남','11440','서울 마포구 창전동 6-206','301호','010-3221-6063','2021-08-18 10:37:48','2021-08-18 10:37:48'),(4,'백은성','oogab@gmail.com','두자','$2b$12$fl6ZPPBpphrGoV/TII1ksO5IheFDCAXVryfSlczlPiGpoTm0pVHy.',23,'여','11440','서울 마포구 창전동 6-206','301호','010-1234-1234','2021-08-18 21:20:25','2021-08-19 04:48:23'),(5,'김민주','minjoo0112@naver.com','밈','$2b$12$QQerdA6cGpMEctC9tcGY9uSM8YCC7mccC9k3AofIimwDJY8CpTHu2',25,'여','11470','서울 양천구 신목로 9','101동','010-8296-9303','2021-08-19 04:09:28','2021-08-19 04:09:28'),(6,'백유리','chsem145@naver.com','유리임','$2b$12$LtWx7tHV2MlbmyVfnqqBles4ivZQg2/WirFSrv34Gm1Jg/AY4ha4G',25,'여','11650','서울 서초구 양재동 392-20','403','010-1111-1111','2021-08-19 04:45:15','2021-08-19 05:48:11'),(7,'mj','mj@naver.com','mj','$2b$12$pBtdUtSxR/d3E/Egp88vneLC8ogFfyzPbyO9QNNIHmkoxGoueyX3.',25,'여','11680','서울 강남구 가로수길 5','dd','010-8296-9303','2021-08-19 04:46:31','2021-08-19 04:46:31'),(8,'허남규','gjskarb1492@naver.com','허씨초콜릿','$2b$12$ra/hCi8A3uBUfbVC8osCu.RAP5rbP48u0J4uITPbv9GJ8dfFriAmu',27,'남','11740','서울 강동구 상암로79길 88','711동 504호','010-4911-4417','2021-08-19 04:52:58','2021-08-19 04:52:58'),(9,'김민지','kimminji0527@naver.com','김민지','$2b$12$myGRWCu1z1TpxNCo5w3c1.L7AK1SNrbsIsOiTP1Q/6tBPjqvWOsRy',24,'여','11215','서울 광진구 화양동 36-90','202호','010-4569-8423','2021-08-19 04:56:59','2021-08-19 04:56:59'),(10,'test1','test1@ssafy.com','욜로','$2b$12$8Z0TWYZQO92BaTN7PUE7Be3X8dAZuFW9lNrL7/zZx5qzDDPPEnf6a',0,'기타','50110','제주특별자치도 제주시 첨단로 4','101','010-8296-9303','2021-08-19 06:01:41','2021-08-19 06:01:41'),(11,'최아현','cah1113@naver.com','초코만쥬','$2b$12$nrlbSjD4gPfocJHFqudqPeL4Z1kkxE7qLTMkRJpgFbh2IqbOfkPXy',25,'여','41465','경기 용인시 수지구 포은대로 477','707호','010-5355-4313','2021-08-19 11:28:45','2021-08-19 11:28:45'),(12,'오승후','tmdgn0532@naver.com','OWho','$2b$12$08W03LMqCb5olRBnsiP13uTIdT6vATMmt8GPmP0cuIpRyoQjKB/4u',13,'남','41820','경기 가평군 가평읍 가랫골길 1','asdad','010-9298-0935','2021-08-19 11:43:35','2021-08-19 11:43:35'),(13,'장동균','jangdongkyun6576@gmail.com','호후','$2b$12$sF.CoDgtc1fYv0bXD8hH8.2ug8nQSh3oSS/J6KuQjp0713KG8exXq',0,'기타','11215','서울 광진구 뚝섬로 553','usung 5th apartment 105','010-3772-6576','2021-08-20 04:18:28','2021-08-20 04:18:28'),(14,'서요셉','tjdytpq0310@gmail.com','yoseph','$2b$12$AeoqGlX7IT8urHswfwA75On2C4u9FZnwpu3l1WUeAtZz.OOvObTne',26,'남','11560','서울 영등포구 신풍로12길 5','301','010-9953-4290','2021-08-20 04:18:30','2021-08-20 04:18:30'),(15,'하마','hi@naver.com','하마','$2b$12$d5TDtR0ey5aeZacZkRP42OoSD/C0ErQzDM1mYM/4SSjLj6/G3UAOC',0,'기타','11680','서울 강남구 가로수길 5','호호호','010-0000-0000','2021-08-20 04:19:22','2021-08-20 04:19:22'),(16,'ss','ssafy@ssafy.com','afy','$2b$12$dbLOySJ9/vyeE3p3QDgywueh35V.ExeL3oo2yX49D0DQ92sTQgjne',5,'기타','11680','서울 강남구 테헤란로 212','ssafy','010-0000-0000','2021-08-20 04:31:42','2021-08-20 04:31:42'),(17,'qq','mj3@naver.com','qq','$2b$12$946YEvSxNg5kDPFQCFng8usoIFuEe6BNRUc5Y8Zkk1bkkdkqIatLe',0,'여','26440','부산 강서구 르노삼성대로 14','ff','010-1234-1234','2021-10-19 14:50:34','2021-10-19 14:50:34'),(18,'백유리','test@test.com','유리','$2b$12$SZOxOL3wtl/r5RcslDXQUuozUI8/he/rOLfsa7bjGKwcBUQ4HKZfC',10,'기타','41135','경기 성남시 분당구 대왕판교로606번길 45','.','010-5386-6713','2021-11-08 01:43:30','2021-11-08 01:43:30'),(22,'e','test33@test.com','e','$2b$12$o0xdUlE2cPfpSVTzJcoY1Ok2WNFvvpBEP3LQ/cJWikUAeg7FODiDm',8,'기타','41135','경기 성남시 분당구 대왕판교로 477','.','010-5386-6713','2021-11-08 02:16:35','2021-11-08 02:16:35');
/*!40000 ALTER TABLE `Users` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-18 17:16:14
