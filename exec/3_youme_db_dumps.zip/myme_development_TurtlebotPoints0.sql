-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: ssafy-pjt1-dbserver.cotmr33tcon0.ap-northeast-2.rds.amazonaws.com    Database: myme_development
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `TurtlebotPoints`
--

DROP TABLE IF EXISTS `TurtlebotPoints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TurtlebotPoints` (
  `id` int NOT NULL AUTO_INCREMENT,
  `initPosePositionX` float NOT NULL,
  `initPosePositionY` float NOT NULL,
  `initPosePositionZ` float NOT NULL,
  `initPoseOrientationW` float NOT NULL,
  `BedPositionX` float NOT NULL,
  `BedPositionY` float NOT NULL,
  `BedPositionZ` float NOT NULL,
  `BedOrientationW` float NOT NULL,
  `CoffeePositionX` float NOT NULL,
  `CoffeePositionY` float NOT NULL,
  `CoffeePositionZ` float NOT NULL,
  `CoffeeOrientationW` float NOT NULL,
  `MirrorPositionX` float NOT NULL,
  `MirrorPositionY` float NOT NULL,
  `MirrorPositionZ` float NOT NULL,
  `MirrorOrientationW` float NOT NULL,
  `WorkspacePositionX` float NOT NULL,
  `WorkspacePositionY` float NOT NULL,
  `WorkspacePositionZ` float NOT NULL,
  `WorkspaceOrientationW` float NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `UsersYoumeId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `UsersYoumeId` (`UsersYoumeId`),
  CONSTRAINT `TurtlebotPoints_ibfk_1` FOREIGN KEY (`UsersYoumeId`) REFERENCES `UsersYoumes` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TurtlebotPoints`
--

LOCK TABLES `TurtlebotPoints` WRITE;
/*!40000 ALTER TABLE `TurtlebotPoints` DISABLE KEYS */;
INSERT INTO `TurtlebotPoints` VALUES (1,-0.0374852,-0.00544593,0,0.999602,0.254673,0.880391,0,1,-0.0374852,-0.00544593,0,0.999602,0.254673,0.880391,0,1,-0.0374852,-0.00544593,0,0.999602,'0000-00-00 00:00:00','0000-00-00 00:00:00',1),(2,0.329783,0.0877061,-0.106756,0.994285,1.33979,1.21659,-0.984636,0.17462,2.06266,0.68017,-0.0709374,0.997481,0.80668,-0.413903,-0.5761,0.817379,1.88308,1.86004,0.798939,0.601412,'0000-00-00 00:00:00','0000-00-00 00:00:00',2);
/*!40000 ALTER TABLE `TurtlebotPoints` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-18 17:16:14
